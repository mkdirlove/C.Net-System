﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace WindowsFormsApp_login
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        MySqlConnection conn = new MySqlConnection("datasource=localhost;port=3306;Initial Catalog='login';username=root;password=");
        string user { get; set; }
        string pass { get; set; }

        private void button1_Click(object sender, EventArgs e)
        {
            string select = ("SELECT username, password FROM tbl_reg WHERE username = @username AND password = @password");
            MySqlCommand command = new MySqlCommand(select, conn);
            command.Parameters.Add("@username", MySqlDbType.VarChar).Value = txtbox_username.Text;
            command.Parameters.Add("@password", MySqlDbType.VarChar).Value = txtbox_pass.Text;

            conn.Open();
            MySqlDataReader dr = command.ExecuteReader();
            while (dr.Read())
            {
                user = dr["username"].ToString();
                pass = dr["password"].ToString();
            }
            dr.Close();
            conn.Close();

            if (txtbox_username.Text == user & txtbox_pass.Text == pass)
            {
                MessageBox.Show("SUCCESS");
                txtbox_username.Clear();
                txtbox_pass.Clear();
            }

            else
            {
                MessageBox.Show("INCORRECT");
            }
        }
        public void zcx(){
    }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {

                string insert = "INSERT INTO tbl_reg (username, password) VALUES (@username, @password)";
                MySqlCommand command = new MySqlCommand(insert, conn);

                command.Parameters.Add("@username", MySqlDbType.VarChar).Value = txtbox_username.Text;
                command.Parameters.Add("@password", MySqlDbType.VarChar).Value = txtbox_pass.Text;

                conn.Open();
                command.ExecuteNonQuery();
                MessageBox.Show("REGISTERED");
                txtbox_username.Clear();
                txtbox_pass.Clear();
                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Mali");
            }
            finally
            {
                conn.Close();
            }
        }
    }
}
